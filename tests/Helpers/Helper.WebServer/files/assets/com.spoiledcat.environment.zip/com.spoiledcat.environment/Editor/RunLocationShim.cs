// Copyright 2016-2019 Andreia Gaita
//
// This work is licensed under the terms of the MIT license.
// For a copy, see <https://opensource.org/licenses/MIT>.

#if UNITY_EDITOR || UNITY_STANDALONE

using UnityEngine;
class RunLocationShim : ScriptableObject
{
}

#endif
